/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: 'export',
  // basePath: '/your-repo-name', // Replace 'your-repo-name' with your actual GitHub repository name
  // trailingSlash: true,
};

export default nextConfig;
